import { createMiddlewareClient } from "@supabase/auth-helpers-nextjs"
import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export async function middleware(req: NextRequest) {
  const res = NextResponse.next()
  const supabase = createMiddlewareClient({ req, res })

  const {
    data: { session },
  } = await supabase.auth.getSession()

  // If there's no session and the user is trying to access a protected route
  if (!session && req.nextUrl.pathname.startsWith("/dashboard")) {
    const redirectUrl = new URL("/login", req.url)
    return NextResponse.redirect(redirectUrl)
  }

  // If there's a session, check role-based access
  if (session) {
    const { data: profile } = await supabase.from("profiles").select("role").eq("id", session.user.id).single()

    // Redirect if trying to access a route for a different role
    if (profile) {
      const { role } = profile
      const path = req.nextUrl.pathname

      if (path.startsWith("/dashboard/admin") && role !== "admin") {
        const redirectUrl = new URL(`/dashboard/${role}`, req.url)
        return NextResponse.redirect(redirectUrl)
      }

      if (path.startsWith("/dashboard/donator") && role !== "donator") {
        const redirectUrl = new URL(`/dashboard/${role}`, req.url)
        return NextResponse.redirect(redirectUrl)
      }

      if (path.startsWith("/dashboard/ngo") && role !== "ngo") {
        const redirectUrl = new URL(`/dashboard/${role}`, req.url)
        return NextResponse.redirect(redirectUrl)
      }
    }
  }

  return res
}

export const config = {
  matcher: ["/dashboard/:path*", "/login", "/register"],
}
