"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Package, Calendar, CheckCircle2, Clock, TrendingUp, Award, Plus, Users } from "lucide-react"
import Link from "next/link"
import { useAuth } from "@/components/auth-provider"
import { donationService } from "@/lib/services/donation-service"
import { useToast } from "@/hooks/use-toast"

type Donation = {
  id: string
  food_type: string
  quantity: number
  unit: string
  status: "available" | "claimed" | "collected" | "expired"
  created_at: string
  pickups?: any[]
}

export default function DonatorDashboard() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [donations, setDonations] = useState<Donation[]>([])
  const [stats, setStats] = useState({
    totalDonations: 0,
    upcomingPickups: 0,
    totalWeight: 0,
    mealsProvided: 0,
    ngosSupported: 0,
  })
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchDonations = async () => {
      if (!user) return

      try {
        const donationsData = await donationService.getDonationsByDonor(user.id)
        setDonations(donationsData)

        // Calculate stats
        const totalDonations = donationsData.length
        const upcomingPickups = donationsData.filter(
          (d) =>
            d.status === "claimed" &&
            d.pickups &&
            d.pickups.length > 0 &&
            d.pickups.some((p) => p.status === "scheduled"),
        ).length

        // Calculate total weight (only count kg for simplicity)
        const totalWeight = donationsData.filter((d) => d.unit === "kg").reduce((sum, d) => sum + d.quantity, 0)

        // Estimate meals provided (1kg = 2.5 meals)
        const mealsProvided = Math.round(totalWeight * 2.5)

        // Count unique NGOs supported
        const uniqueNgos = new Set()
        donationsData.forEach((d) => {
          if (d.pickups) {
            d.pickups.forEach((p) => uniqueNgos.add(p.ngo_id))
          }
        })

        setStats({
          totalDonations,
          upcomingPickups,
          totalWeight,
          mealsProvided,
          ngosSupported: uniqueNgos.size,
        })
      } catch (error) {
        console.error("Error fetching donations:", error)
        toast({
          title: "Error",
          description: "Failed to load your donations. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchDonations()
  }, [user, toast])

  // Calculate monthly goal progress (example: 200kg per month)
  const monthlyGoal = 200
  const monthlyProgress = Math.min(100, Math.round((stats.totalWeight / monthlyGoal) * 100))

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Donator Dashboard</h1>
          <p className="text-muted-foreground">Manage your food donations and track your impact.</p>
        </div>
        <Button asChild className="bg-green-600 hover:bg-green-700">
          <Link href="/dashboard/donator/donate">
            <Plus className="mr-2 h-4 w-4" />
            New Donation
          </Link>
        </Button>
      </div>

      {/* Stats Overview */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Donations</p>
                <p className="text-2xl font-bold">{stats.totalDonations}</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center">
                <Package className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Upcoming Pickups</p>
                <p className="text-2xl font-bold">{stats.upcomingPickups}</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center">
                <Calendar className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Impact Score</p>
                <p className="text-2xl font-bold">{Math.min(100, stats.totalDonations * 2)}</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-amber-100 flex items-center justify-center">
                <Award className="h-6 w-6 text-amber-600" />
              </div>
            </div>
            <div className="mt-4">
              <p className="text-sm text-muted-foreground">
                <span className="text-green-600 font-medium">
                  {stats.totalDonations < 10 ? "Bronze" : stats.totalDonations < 25 ? "Silver" : "Gold"}
                </span>{" "}
                tier donor
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Monthly Goal */}
      <Card>
        <CardHeader>
          <CardTitle>Monthly Donation Goal</CardTitle>
          <CardDescription>Track your progress towards your monthly donation target</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">{monthlyProgress}% Complete</span>
              <span className="text-sm text-muted-foreground">
                {stats.totalWeight}kg / {monthlyGoal}kg
              </span>
            </div>
            <Progress value={monthlyProgress} className="h-2" />
            <p className="text-sm text-muted-foreground">
              {monthlyProgress >= 100
                ? "Congratulations! You've reached your monthly goal."
                : `You're ${monthlyProgress < 50 ? "working towards" : "on track to reach"} your goal! Just ${monthlyGoal - stats.totalWeight}kg more to go this month.`}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Recent Donations */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Donations</CardTitle>
          <CardDescription>Your latest food donations and their status</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
            </div>
          ) : donations.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">You haven't made any donations yet.</p>
              <Button asChild className="mt-4 bg-green-600 hover:bg-green-700">
                <Link href="/dashboard/donator/donate">Create Your First Donation</Link>
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {donations.slice(0, 4).map((donation) => (
                <div
                  key={donation.id}
                  className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0"
                >
                  <div className="flex items-center gap-4">
                    <div className="h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center">
                      <Package className="h-5 w-5 text-gray-600" />
                    </div>
                    <div>
                      <p className="font-medium">
                        {donation.food_type.charAt(0).toUpperCase() + donation.food_type.slice(1)}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(donation.created_at).toLocaleDateString()} • {donation.quantity} {donation.unit}
                      </p>
                    </div>
                  </div>
                  <div>
                    {donation.status === "available" ? (
                      <span className="inline-flex items-center rounded-full bg-amber-100 px-2.5 py-0.5 text-xs font-medium text-amber-800">
                        <Clock className="mr-1 h-3 w-3" />
                        Available
                      </span>
                    ) : donation.status === "claimed" ? (
                      <span className="inline-flex items-center rounded-full bg-blue-100 px-2.5 py-0.5 text-xs font-medium text-blue-800">
                        <Calendar className="mr-1 h-3 w-3" />
                        Pickup Scheduled
                      </span>
                    ) : (
                      <span className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800">
                        <CheckCircle2 className="mr-1 h-3 w-3" />
                        Collected
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
          {donations.length > 0 && (
            <div className="mt-6 flex justify-center">
              <Button variant="outline" asChild>
                <Link href="/dashboard/donator/history">View All Donations</Link>
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Impact Stats */}
      <Card>
        <CardHeader>
          <CardTitle>Your Impact</CardTitle>
          <CardDescription>The difference your donations are making</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="bg-gray-50 p-4 rounded-lg text-center">
              <div className="flex justify-center mb-2">
                <TrendingUp className="h-8 w-8 text-green-600" />
              </div>
              <p className="text-2xl font-bold">{stats.totalWeight}kg</p>
              <p className="text-sm text-muted-foreground">Total Food Saved</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg text-center">
              <div className="flex justify-center mb-2">
                <Users className="h-8 w-8 text-blue-600" />
              </div>
              <p className="text-2xl font-bold">{stats.mealsProvided}</p>
              <p className="text-sm text-muted-foreground">Meals Provided</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg text-center">
              <div className="flex justify-center mb-2">
                <Award className="h-8 w-8 text-amber-600" />
              </div>
              <p className="text-2xl font-bold">{stats.ngosSupported}</p>
              <p className="text-sm text-muted-foreground">NGOs Supported</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
