"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { DatePicker } from "@/components/date-picker"
import { Loader2, ArrowLeft, Upload } from "lucide-react"
import Link from "next/link"
import { useAuth } from "@/components/auth-provider"
import { donationService } from "@/lib/services/donation-service"
import { storageService } from "@/lib/services/storage-service"
import { useToast } from "@/hooks/use-toast"

export default function DonatePage() {
  const router = useRouter()
  const { user } = useAuth()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    foodType: "",
    quantity: "",
    unit: "kg",
    description: "",
    expiryDate: new Date(),
    pickupDate: new Date(),
    pickupTimeSlot: "",
    address: "",
    contactName: "",
    contactPhone: "",
    termsAccepted: false,
  })
  const [images, setImages] = useState<File[]>([])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleCheckboxChange = (checked: boolean) => {
    setFormData((prev) => ({ ...prev, termsAccepted: checked }))
  }

  const handleDateChange = (name: string, date: Date) => {
    setFormData((prev) => ({ ...prev, [name]: date }))
  }

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newImages = Array.from(e.target.files)
      setImages((prev) => [...prev, ...newImages])
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!user) {
      toast({
        title: "Authentication error",
        description: "You must be logged in to create a donation.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      // Create the donation
      const donation = await donationService.createDonation({
        donor_id: user.id,
        food_type: formData.foodType,
        quantity: Number.parseFloat(formData.quantity),
        unit: formData.unit,
        description: formData.description,
        expiry_date: formData.expiryDate.toISOString(),
        pickup_date: formData.pickupDate.toISOString(),
        pickup_time_slot: formData.pickupTimeSlot,
        address: formData.address,
        contact_name: formData.contactName,
        contact_phone: formData.contactPhone,
      })

      // Upload images if any
      if (images.length > 0) {
        const uploadPromises = images.map((image) => storageService.uploadDonationImage(donation.id, image))
        await Promise.all(uploadPromises)
      }

      toast({
        title: "Donation created",
        description: "Your donation has been successfully created.",
      })

      router.push("/dashboard/donator")
    } catch (err) {
      console.error("Error submitting donation:", err)
      toast({
        title: "Error creating donation",
        description: "There was an error creating your donation. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <Link
          href="/dashboard/donator"
          className="inline-flex items-center text-sm text-gray-600 hover:text-gray-900 mb-4"
        >
          <ArrowLeft className="mr-1 h-4 w-4" />
          Back to Dashboard
        </Link>
        <h1 className="text-2xl font-bold tracking-tight">Donate Food</h1>
        <p className="text-muted-foreground">Fill out the form below to list food items for donation</p>
      </div>

      <Card>
        <form onSubmit={handleSubmit}>
          <CardHeader>
            <CardTitle>Donation Details</CardTitle>
            <CardDescription>Provide information about the food you wish to donate</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="foodType">Food Type</Label>
                <Select onValueChange={(value) => handleSelectChange("foodType", value)} required>
                  <SelectTrigger id="foodType">
                    <SelectValue placeholder="Select food type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="produce">Fresh Produce</SelectItem>
                    <SelectItem value="bakery">Bakery Items</SelectItem>
                    <SelectItem value="dairy">Dairy Products</SelectItem>
                    <SelectItem value="canned">Canned Goods</SelectItem>
                    <SelectItem value="prepared">Prepared Meals</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="quantity">Quantity</Label>
                  <Input
                    id="quantity"
                    name="quantity"
                    type="number"
                    placeholder="Amount"
                    value={formData.quantity}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="unit">Unit</Label>
                  <Select defaultValue="kg" onValueChange={(value) => handleSelectChange("unit", value)}>
                    <SelectTrigger id="unit">
                      <SelectValue placeholder="Unit" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="kg">Kilograms (kg)</SelectItem>
                      <SelectItem value="lbs">Pounds (lbs)</SelectItem>
                      <SelectItem value="items">Items</SelectItem>
                      <SelectItem value="boxes">Boxes</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  name="description"
                  placeholder="Describe the food items you're donating (e.g., 'Fresh vegetables from our garden', 'Day-old bread and pastries')"
                  value={formData.description}
                  onChange={handleChange}
                  rows={3}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="expiryDate">Expiry Date</Label>
                <DatePicker
                  id="expiryDate"
                  date={formData.expiryDate}
                  onDateChange={(date) => handleDateChange("expiryDate", date)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="pickupDate">Preferred Pickup Date</Label>
                <DatePicker
                  id="pickupDate"
                  date={formData.pickupDate}
                  onDateChange={(date) => handleDateChange("pickupDate", date)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="pickupTimeSlot">Preferred Pickup Time</Label>
                <Select onValueChange={(value) => handleSelectChange("pickupTimeSlot", value)} required>
                  <SelectTrigger id="pickupTimeSlot">
                    <SelectValue placeholder="Select time slot" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="morning">Morning (8AM - 12PM)</SelectItem>
                    <SelectItem value="afternoon">Afternoon (12PM - 4PM)</SelectItem>
                    <SelectItem value="evening">Evening (4PM - 8PM)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="images">Food Images (Optional)</Label>
                <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                  <div className="space-y-1 text-center">
                    <Upload className="mx-auto h-12 w-12 text-gray-400" />
                    <div className="flex text-sm text-gray-600">
                      <label
                        htmlFor="images"
                        className="relative cursor-pointer bg-white rounded-md font-medium text-green-600 hover:text-green-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-green-500"
                      >
                        <span>Upload images</span>
                        <Input
                          id="images"
                          name="images"
                          type="file"
                          accept="image/*"
                          multiple
                          className="sr-only"
                          onChange={handleImageChange}
                        />
                      </label>
                      <p className="pl-1">or drag and drop</p>
                    </div>
                    <p className="text-xs text-gray-500">PNG, JPG, GIF up to 10MB</p>
                  </div>
                </div>
                {images.length > 0 && (
                  <div className="mt-2">
                    <p className="text-sm text-gray-500">{images.length} image(s) selected</p>
                  </div>
                )}
              </div>
            </div>

            <div className="border-t pt-6">
              <h3 className="text-lg font-medium mb-4">Pickup Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="address">Pickup Address</Label>
                  <Textarea
                    id="address"
                    name="address"
                    placeholder="Full address where the food can be picked up"
                    value={formData.address}
                    onChange={handleChange}
                    rows={2}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="contactName">Contact Person</Label>
                  <Input
                    id="contactName"
                    name="contactName"
                    placeholder="Name of contact person"
                    value={formData.contactName}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="contactPhone">Contact Phone</Label>
                  <Input
                    id="contactPhone"
                    name="contactPhone"
                    placeholder="Phone number"
                    value={formData.contactPhone}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="termsAccepted"
                checked={formData.termsAccepted}
                onCheckedChange={handleCheckboxChange}
                required
              />
              <label
                htmlFor="termsAccepted"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                I confirm that the food is safe for consumption and meets food safety standards
              </label>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" type="button" onClick={() => router.back()}>
              Cancel
            </Button>
            <Button type="submit" className="bg-green-600 hover:bg-green-700" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Submitting...
                </>
              ) : (
                "Submit Donation"
              )}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}
