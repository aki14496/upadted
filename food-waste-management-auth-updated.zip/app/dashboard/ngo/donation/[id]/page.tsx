"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, MapPin, Calendar, Clock, Building2, Phone, User } from "lucide-react"
import { donationService } from "@/lib/services/donation-service"
import { pickupService } from "@/lib/services/pickup-service"
import { storageService } from "@/lib/services/storage-service"
import { useAuth } from "@/components/auth-provider"
import { useToast } from "@/hooks/use-toast"

export default function DonationDetailsPage() {
  const params = useParams()
  const router = useRouter()
  const { user } = useAuth()
  const { toast } = useToast()
  const [donation, setDonation] = useState<any>(null)
  const [images, setImages] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isClaiming, setIsClaiming] = useState(false)

  useEffect(() => {
    const fetchDonation = async () => {
      try {
        const donationData = await donationService.getDonationById(params.id as string)
        setDonation(donationData)

        // Fetch images
        const imagesData = await storageService.getDonationImages(params.id as string)
        setImages(imagesData)
      } catch (error) {
        console.error("Error fetching donation:", error)
        toast({
          title: "Error",
          description: "Failed to load donation details. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchDonation()
  }, [params.id, toast])

  const handleClaimDonation = async () => {
    if (!user) {
      toast({
        title: "Authentication error",
        description: "You must be logged in to claim a donation.",
        variant: "destructive",
      })
      return
    }

    setIsClaiming(true)

    try {
      // Schedule pickup for tomorrow
      const tomorrow = new Date()
      tomorrow.setDate(tomorrow.getDate() + 1)

      await pickupService.createPickup({
        donation_id: donation.id,
        ngo_id: user.id,
        scheduled_date: tomorrow.toISOString(),
        notes: "Claimed through the platform",
      })

      toast({
        title: "Donation claimed",
        description: "You have successfully claimed this donation. Check your scheduled pickups for details.",
      })

      router.push("/dashboard/ngo/pickups")
    } catch (error) {
      console.error("Error claiming donation:", error)
      toast({
        title: "Error",
        description: "Failed to claim this donation. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsClaiming(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    )
  }

  if (!donation) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-2">Donation Not Found</h2>
        <p className="text-muted-foreground mb-6">The donation you're looking for doesn't exist or has been removed.</p>
        <Button asChild>
          <Link href="/dashboard/ngo/available">Back to Available Donations</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <Link
          href="/dashboard/ngo/available"
          className="inline-flex items-center text-sm text-gray-600 hover:text-gray-900 mb-4"
        >
          <ArrowLeft className="mr-1 h-4 w-4" />
          Back to Available Donations
        </Link>
        <h1 className="text-2xl font-bold tracking-tight capitalize">{donation.food_type} Donation</h1>
        <p className="text-muted-foreground">Review donation details and claim if interested</p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Donation Details</CardTitle>
              <CardDescription>Information about the food donation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-wrap gap-4">
                <Badge variant="outline" className="bg-green-50 text-green-700 hover:bg-green-50 text-sm px-3 py-1">
                  {donation.quantity} {donation.unit}
                </Badge>
                <Badge variant="outline" className="bg-blue-50 text-blue-700 hover:bg-blue-50 text-sm px-3 py-1">
                  Expires: {new Date(donation.expiry_date).toLocaleDateString()}
                </Badge>
                <Badge variant="outline" className="bg-amber-50 text-amber-700 hover:bg-amber-50 text-sm px-3 py-1">
                  Posted: {new Date(donation.created_at).toLocaleDateString()}
                </Badge>
              </div>

              <div>
                <h3 className="font-medium mb-2">Description</h3>
                <p className="text-gray-600">{donation.description || "No description provided."}</p>
              </div>

              {images.length > 0 && (
                <div>
                  <h3 className="font-medium mb-2">Images</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {images.map((image) => (
                      <div key={image.id} className="aspect-square rounded-md overflow-hidden bg-gray-100">
                        <img
                          src={image.publicUrl || "/placeholder.svg"}
                          alt="Donation"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div>
                <h3 className="font-medium mb-2">Pickup Information</h3>
                <div className="space-y-3">
                  <div className="flex items-start gap-2">
                    <MapPin className="h-5 w-5 text-gray-500 mt-0.5" />
                    <div>
                      <p className="font-medium">Address</p>
                      <p className="text-gray-600">{donation.address}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-2">
                    <Calendar className="h-5 w-5 text-gray-500 mt-0.5" />
                    <div>
                      <p className="font-medium">Preferred Pickup Date</p>
                      <p className="text-gray-600">
                        {donation.pickup_date ? new Date(donation.pickup_date).toLocaleDateString() : "Flexible"}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-2">
                    <Clock className="h-5 w-5 text-gray-500 mt-0.5" />
                    <div>
                      <p className="font-medium">Preferred Time Slot</p>
                      <p className="text-gray-600">
                        {donation.pickup_time_slot === "morning"
                          ? "Morning (8AM - 12PM)"
                          : donation.pickup_time_slot === "afternoon"
                            ? "Afternoon (12PM - 4PM)"
                            : donation.pickup_time_slot === "evening"
                              ? "Evening (4PM - 8PM)"
                              : "Flexible"}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button
                className="w-full bg-green-600 hover:bg-green-700"
                onClick={handleClaimDonation}
                disabled={isClaiming}
              >
                {isClaiming ? "Processing..." : "Claim This Donation"}
              </Button>
            </CardFooter>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Donor Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-2">
                <Building2 className="h-5 w-5 text-gray-500 mt-0.5" />
                <div>
                  <p className="font-medium">Organization</p>
                  <p className="text-gray-600">{donation.profiles.organization || "Individual Donor"}</p>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <User className="h-5 w-5 text-gray-500 mt-0.5" />
                <div>
                  <p className="font-medium">Contact Person</p>
                  <p className="text-gray-600">{donation.contact_name}</p>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <Phone className="h-5 w-5 text-gray-500 mt-0.5" />
                <div>
                  <p className="font-medium">Contact Phone</p>
                  <p className="text-gray-600">{donation.contact_phone}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Need Help?</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                If you have questions about this donation or need assistance with pickup, please contact our support
                team.
              </p>
              <Button variant="outline" className="w-full">
                Contact Support
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
