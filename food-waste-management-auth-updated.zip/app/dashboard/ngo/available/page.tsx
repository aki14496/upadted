"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { Package, MapPin, Clock, Filter, SearchIcon, ArrowLeft, Calendar, Building2 } from "lucide-react"
import { useAuth } from "@/components/auth-provider"
import { donationService } from "@/lib/services/donation-service"
import { pickupService } from "@/lib/services/pickup-service"
import { useToast } from "@/hooks/use-toast"

type Donation = {
  id: string
  food_type: string
  quantity: number
  unit: string
  description: string
  expiry_date: string
  address: string
  contact_name: string
  contact_phone: string
  status: string
  created_at: string
  profiles: {
    full_name: string
    organization: string
  }
}

export default function AvailableDonationsPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [searchTerm, setSearchTerm] = useState("")
  const [foodType, setFoodType] = useState("")
  const [distance, setDistance] = useState([5])
  const [showFilters, setShowFilters] = useState(false)
  const [donations, setDonations] = useState<Donation[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [claimingId, setClaimingId] = useState<string | null>(null)

  useEffect(() => {
    const fetchDonations = async () => {
      try {
        const data = await donationService.getAvailableDonations()
        setDonations(data)
      } catch (error) {
        console.error("Error fetching donations:", error)
        toast({
          title: "Error",
          description: "Failed to load available donations. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchDonations()

    // Set up real-time subscription
    const subscription = donationService.subscribeToAvailableDonations((payload) => {
      // Update donations when there's a change
      fetchDonations()
    })

    return () => {
      subscription.unsubscribe()
    }
  }, [toast])

  // Filter donations based on search term, food type, and distance
  const filteredDonations = donations.filter((donation) => {
    const matchesSearch =
      searchTerm === "" ||
      donation.food_type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      donation.profiles.organization.toLowerCase().includes(searchTerm.toLowerCase()) ||
      donation.description.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesType = foodType === "" || donation.food_type === foodType

    // Note: In a real app, you would calculate actual distance based on coordinates
    // For demo purposes, we'll assume all donations are within the distance filter
    const matchesDistance = true

    return matchesSearch && matchesType && matchesDistance
  })

  const handleClaimDonation = async (donationId: string) => {
    if (!user) {
      toast({
        title: "Authentication error",
        description: "You must be logged in to claim a donation.",
        variant: "destructive",
      })
      return
    }

    setClaimingId(donationId)

    try {
      const donation = await donationService.getDonationById(donationId)

      // Schedule pickup for tomorrow
      const tomorrow = new Date()
      tomorrow.setDate(tomorrow.getDate() + 1)

      await pickupService.createPickup({
        donation_id: donationId,
        ngo_id: user.id,
        scheduled_date: tomorrow.toISOString(),
        notes: "Claimed through the platform",
      })

      toast({
        title: "Donation claimed",
        description: "You have successfully claimed this donation. Check your scheduled pickups for details.",
      })

      // Remove the claimed donation from the list
      setDonations(donations.filter((d) => d.id !== donationId))
    } catch (error) {
      console.error("Error claiming donation:", error)
      toast({
        title: "Error",
        description: "Failed to claim this donation. Please try again.",
        variant: "destructive",
      })
    } finally {
      setClaimingId(null)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <Link href="/dashboard/ngo" className="inline-flex items-center text-sm text-gray-600 hover:text-gray-900 mb-4">
          <ArrowLeft className="mr-1 h-4 w-4" />
          Back to Dashboard
        </Link>
        <h1 className="text-2xl font-bold tracking-tight">Available Donations</h1>
        <p className="text-muted-foreground">Browse and claim food donations in your area</p>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search by food type, donor, etc."
                className="pl-9"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button variant="outline" className="md:w-auto" onClick={() => setShowFilters(!showFilters)}>
              <Filter className="mr-2 h-4 w-4" />
              Filters
            </Button>
          </div>

          {showFilters && (
            <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t">
              <div>
                <label className="text-sm font-medium mb-2 block">Food Type</label>
                <Select value={foodType} onValueChange={setFoodType}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="produce">Fresh Produce</SelectItem>
                    <SelectItem value="bakery">Bakery Items</SelectItem>
                    <SelectItem value="dairy">Dairy Products</SelectItem>
                    <SelectItem value="canned">Canned Goods</SelectItem>
                    <SelectItem value="prepared">Prepared Meals</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Distance: {distance[0]} miles</label>
                <Slider value={distance} onValueChange={setDistance} max={10} step={0.5} />
              </div>

              <div className="flex items-end">
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => {
                    setSearchTerm("")
                    setFoodType("")
                    setDistance([5])
                  }}
                >
                  Reset Filters
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Results */}
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-lg font-medium">
            {filteredDonations.length} {filteredDonations.length === 1 ? "donation" : "donations"} available
          </h2>
          <Select defaultValue="distance">
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="distance">Distance (Nearest)</SelectItem>
              <SelectItem value="recent">Recently Posted</SelectItem>
              <SelectItem value="expiry">Expiry (Soonest)</SelectItem>
              <SelectItem value="quantity">Quantity (Highest)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
          </div>
        ) : filteredDonations.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center">
              <Package className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">No donations found</h3>
              <p className="text-muted-foreground mb-4">
                Try adjusting your filters or search term to find more donations.
              </p>
              <Button
                variant="outline"
                onClick={() => {
                  setSearchTerm("")
                  setFoodType("")
                  setDistance([5])
                }}
              >
                Reset Filters
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredDonations.map((donation) => (
              <Card key={donation.id} className="overflow-hidden">
                <div className="bg-gray-100 p-4 flex items-center justify-center">
                  <Package className="h-12 w-12 text-gray-500" />
                </div>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-semibold text-lg capitalize">{donation.food_type}</h3>
                    <Badge variant="outline" className="bg-green-50 text-green-700 hover:bg-green-50">
                      {donation.quantity} {donation.unit}
                    </Badge>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-center text-sm text-gray-500">
                      <Building2 className="mr-2 h-4 w-4" />
                      {donation.profiles.organization || donation.profiles.full_name}
                    </div>
                    <div className="flex items-center text-sm text-gray-500">
                      <MapPin className="mr-2 h-4 w-4" />
                      {donation.address}
                    </div>
                    <div className="flex items-center text-sm text-gray-500">
                      <Calendar className="mr-2 h-4 w-4" />
                      Expires in {new Date(donation.expiry_date).toLocaleDateString()}
                    </div>
                    <div className="flex items-center text-sm text-gray-500">
                      <Clock className="mr-2 h-4 w-4" />
                      Posted {new Date(donation.created_at).toLocaleDateString()}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      className="flex-1 bg-green-600 hover:bg-green-700"
                      onClick={() => handleClaimDonation(donation.id)}
                      disabled={claimingId === donation.id}
                    >
                      {claimingId === donation.id ? "Claiming..." : "Claim"}
                    </Button>
                    <Button variant="outline" className="flex-1" asChild>
                      <Link href={`/dashboard/ngo/donation/${donation.id}`}>Details</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
