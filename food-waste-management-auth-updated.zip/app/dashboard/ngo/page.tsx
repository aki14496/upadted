import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Package, Calendar, CheckCircle2, Clock, MapPin, Users, Search } from "lucide-react"
import Link from "next/link"

export default function NgoDashboard() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">NGO Dashboard</h1>
          <p className="text-muted-foreground">Find and manage food donations for your organization.</p>
        </div>
        <Button asChild className="bg-green-600 hover:bg-green-700">
          <Link href="/dashboard/ngo/available">
            <Search className="mr-2 h-4 w-4" />
            Find Donations
          </Link>
        </Button>
      </div>

      {/* Stats Overview */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Available Donations</p>
                <p className="text-2xl font-bold">24</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center">
                <Package className="h-6 w-6 text-green-600" />
              </div>
            </div>
            <div className="mt-4">
              <p className="text-sm text-muted-foreground">
                <span className="text-green-600 font-medium">+8</span> new since yesterday
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Scheduled Pickups</p>
                <p className="text-2xl font-bold">5</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center">
                <Calendar className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <div className="mt-4">
              <p className="text-sm text-muted-foreground">
                Next pickup in <span className="font-medium">3 hours</span>
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">People Served</p>
                <p className="text-2xl font-bold">1,248</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-amber-100 flex items-center justify-center">
                <Users className="h-6 w-6 text-amber-600" />
              </div>
            </div>
            <div className="mt-4">
              <p className="text-sm text-muted-foreground">
                <span className="text-green-600 font-medium">+15%</span> this month
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Upcoming Pickups */}
      <Card>
        <CardHeader>
          <CardTitle>Upcoming Pickups</CardTitle>
          <CardDescription>Food donations scheduled for pickup</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              {
                name: "Fresh Vegetables",
                location: "Metro Supermarket",
                time: "Today, 2:00 PM",
                distance: "1.2 miles",
              },
              { name: "Bakery Items", location: "City Bakery", time: "Today, 5:30 PM", distance: "0.8 miles" },
              {
                name: "Prepared Meals",
                location: "Green Restaurant",
                time: "Tomorrow, 10:00 AM",
                distance: "2.5 miles",
              },
              { name: "Canned Goods", location: "Community Center", time: "Tomorrow, 3:00 PM", distance: "1.5 miles" },
              { name: "Dairy Products", location: "Fresh Market", time: "In 2 days, 9:00 AM", distance: "3.2 miles" },
            ].map((pickup, i) => (
              <div key={i} className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0">
                <div className="flex items-center gap-4">
                  <div className="h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center">
                    <Package className="h-5 w-5 text-gray-600" />
                  </div>
                  <div>
                    <p className="font-medium">{pickup.name}</p>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <MapPin className="mr-1 h-3 w-3" />
                      {pickup.location} • {pickup.distance}
                    </div>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className="inline-flex items-center rounded-full bg-blue-100 px-2.5 py-0.5 text-xs font-medium text-blue-800">
                    <Clock className="mr-1 h-3 w-3" />
                    {pickup.time}
                  </span>
                  <Button variant="ghost" size="sm">
                    Details
                  </Button>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6 flex justify-center">
            <Button variant="outline">View All Pickups</Button>
          </div>
        </CardContent>
      </Card>

      {/* Recent Collections */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Collections</CardTitle>
          <CardDescription>Food donations you've recently collected</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { name: "Mixed Produce", location: "Farmers Market", date: "Yesterday", weight: "25kg" },
              { name: "Bread and Pastries", location: "Downtown Bakery", date: "2 days ago", weight: "12kg" },
              { name: "Canned Foods", location: "Community Drive", date: "3 days ago", weight: "30kg" },
            ].map((collection, i) => (
              <div key={i} className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0">
                <div className="flex items-center gap-4">
                  <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center">
                    <CheckCircle2 className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <p className="font-medium">{collection.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {collection.location} • {collection.date}
                    </p>
                  </div>
                </div>
                <div>
                  <span className="font-medium">{collection.weight}</span>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6 flex justify-center">
            <Button variant="outline">View Collection History</Button>
          </div>
        </CardContent>
      </Card>

      {/* Impact Map */}
      <Card>
        <CardHeader>
          <CardTitle>Donation Map</CardTitle>
          <CardDescription>Available donations in your area</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="aspect-video bg-gray-100 rounded-md flex items-center justify-center">
            <div className="text-center p-6">
              <MapPin className="h-8 w-8 text-gray-400 mx-auto mb-2" />
              <p className="text-muted-foreground">Map showing nearby donation locations would appear here</p>
              <Button variant="outline" className="mt-4">
                View Full Map
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
