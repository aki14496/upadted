"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Package, MapPin, Calendar, Clock, CheckCircle2, X, ArrowLeft } from "lucide-react"
import { useAuth } from "@/components/auth-provider"
import { pickupService } from "@/lib/services/pickup-service"
import { useToast } from "@/hooks/use-toast"

export default function PickupsPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [pickups, setPickups] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [updatingId, setUpdatingId] = useState<string | null>(null)

  useEffect(() => {
    const fetchPickups = async () => {
      if (!user) return

      try {
        const pickupsData = await pickupService.getPickupsByNgo(user.id)
        setPickups(pickupsData)
      } catch (error) {
        console.error("Error fetching pickups:", error)
        toast({
          title: "Error",
          description: "Failed to load your scheduled pickups. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchPickups()

    // Set up real-time subscription
    const subscription = pickupService.subscribeToPickups(user?.id || "", (payload) => {
      // Update pickups when there's a change
      fetchPickups()
    })

    return () => {
      subscription.unsubscribe()
    }
  }, [user, toast])

  const handleUpdateStatus = async (pickupId: string, status: "completed" | "cancelled") => {
    setUpdatingId(pickupId)

    try {
      await pickupService.updatePickupStatus(pickupId, status)

      // Update local state
      setPickups(pickups.map((pickup) => (pickup.id === pickupId ? { ...pickup, status } : pickup)))

      toast({
        title: status === "completed" ? "Pickup completed" : "Pickup cancelled",
        description:
          status === "completed"
            ? "The pickup has been marked as completed."
            : "The pickup has been cancelled and the donation is available again.",
      })
    } catch (error) {
      console.error(`Error updating pickup status to ${status}:`, error)
      toast({
        title: "Error",
        description: `Failed to update pickup status. Please try again.`,
        variant: "destructive",
      })
    } finally {
      setUpdatingId(null)
    }
  }

  // Filter pickups by status
  const scheduledPickups = pickups.filter((p) => p.status === "scheduled")
  const completedPickups = pickups.filter((p) => p.status === "completed")
  const cancelledPickups = pickups.filter((p) => p.status === "cancelled")

  return (
    <div className="space-y-6">
      <div>
        <Link href="/dashboard/ngo" className="inline-flex items-center text-sm text-gray-600 hover:text-gray-900 mb-4">
          <ArrowLeft className="mr-1 h-4 w-4" />
          Back to Dashboard
        </Link>
        <h1 className="text-2xl font-bold tracking-tight">Scheduled Pickups</h1>
        <p className="text-muted-foreground">Manage your food donation pickups</p>
      </div>

      <Tabs defaultValue="scheduled" className="space-y-6">
        <TabsList>
          <TabsTrigger value="scheduled">Scheduled ({scheduledPickups.length})</TabsTrigger>
          <TabsTrigger value="completed">Completed ({completedPickups.length})</TabsTrigger>
          <TabsTrigger value="cancelled">Cancelled ({cancelledPickups.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="scheduled" className="space-y-6">
          {isLoading ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
            </div>
          ) : scheduledPickups.length === 0 ? (
            <Card>
              <CardContent className="p-6 text-center">
                <Calendar className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No scheduled pickups</h3>
                <p className="text-muted-foreground mb-4">You don't have any scheduled pickups at the moment.</p>
                <Button asChild className="bg-green-600 hover:bg-green-700">
                  <Link href="/dashboard/ngo/available">Find Donations</Link>
                </Button>
              </CardContent>
            </Card>
          ) : (
            scheduledPickups.map((pickup) => (
              <Card key={pickup.id}>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row gap-6">
                    <div className="md:w-1/4 flex items-center justify-center">
                      <div className="h-24 w-24 rounded-full bg-green-100 flex items-center justify-center">
                        <Package className="h-12 w-12 text-green-600" />
                      </div>
                    </div>
                    <div className="md:w-3/4">
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
                        <div>
                          <h3 className="text-xl font-semibold capitalize">{pickup.donations?.food_type} Pickup</h3>
                          <p className="text-muted-foreground">
                            From: {pickup.donations?.profiles?.organization || pickup.donations?.profiles?.full_name}
                          </p>
                        </div>
                        <Badge className="w-fit bg-blue-100 text-blue-800 hover:bg-blue-100">Scheduled</Badge>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                        <div className="flex items-start gap-2">
                          <Calendar className="h-5 w-5 text-gray-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Pickup Date</p>
                            <p className="text-gray-600">{new Date(pickup.scheduled_date).toLocaleDateString()}</p>
                          </div>
                        </div>

                        <div className="flex items-start gap-2">
                          <Package className="h-5 w-5 text-gray-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Quantity</p>
                            <p className="text-gray-600">
                              {pickup.donations?.quantity} {pickup.donations?.unit}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-start gap-2">
                          <MapPin className="h-5 w-5 text-gray-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Address</p>
                            <p className="text-gray-600">{pickup.donations?.address}</p>
                          </div>
                        </div>

                        <div className="flex items-start gap-2">
                          <Clock className="h-5 w-5 text-gray-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Contact</p>
                            <p className="text-gray-600">
                              {pickup.donations?.contact_name}: {pickup.donations?.contact_phone}
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-3">
                        <Button
                          className="bg-green-600 hover:bg-green-700"
                          onClick={() => handleUpdateStatus(pickup.id, "completed")}
                          disabled={updatingId === pickup.id}
                        >
                          <CheckCircle2 className="mr-2 h-4 w-4" />
                          Mark as Collected
                        </Button>
                        <Button
                          variant="outline"
                          className="text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700"
                          onClick={() => handleUpdateStatus(pickup.id, "cancelled")}
                          disabled={updatingId === pickup.id}
                        >
                          <X className="mr-2 h-4 w-4" />
                          Cancel Pickup
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        <TabsContent value="completed" className="space-y-6">
          {isLoading ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
            </div>
          ) : completedPickups.length === 0 ? (
            <Card>
              <CardContent className="p-6 text-center">
                <CheckCircle2 className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No completed pickups</h3>
                <p className="text-muted-foreground mb-4">You haven't completed any pickups yet.</p>
              </CardContent>
            </Card>
          ) : (
            completedPickups.map((pickup) => (
              <Card key={pickup.id}>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row gap-6">
                    <div className="md:w-1/4 flex items-center justify-center">
                      <div className="h-24 w-24 rounded-full bg-gray-100 flex items-center justify-center">
                        <Package className="h-12 w-12 text-gray-600" />
                      </div>
                    </div>
                    <div className="md:w-3/4">
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
                        <div>
                          <h3 className="text-xl font-semibold capitalize">{pickup.donations?.food_type} Pickup</h3>
                          <p className="text-muted-foreground">
                            From: {pickup.donations?.profiles?.organization || pickup.donations?.profiles?.full_name}
                          </p>
                        </div>
                        <Badge className="w-fit bg-green-100 text-green-800 hover:bg-green-100">Completed</Badge>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="flex items-start gap-2">
                          <Calendar className="h-5 w-5 text-gray-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Pickup Date</p>
                            <p className="text-gray-600">{new Date(pickup.scheduled_date).toLocaleDateString()}</p>
                          </div>
                        </div>

                        <div className="flex items-start gap-2">
                          <Package className="h-5 w-5 text-gray-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Quantity</p>
                            <p className="text-gray-600">
                              {pickup.donations?.quantity} {pickup.donations?.unit}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        <TabsContent value="cancelled" className="space-y-6">
          {isLoading ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
            </div>
          ) : cancelledPickups.length === 0 ? (
            <Card>
              <CardContent className="p-6 text-center">
                <X className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No cancelled pickups</h3>
                <p className="text-muted-foreground mb-4">You don't have any cancelled pickups.</p>
              </CardContent>
            </Card>
          ) : (
            cancelledPickups.map((pickup) => (
              <Card key={pickup.id}>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row gap-6">
                    <div className="md:w-1/4 flex items-center justify-center">
                      <div className="h-24 w-24 rounded-full bg-gray-100 flex items-center justify-center">
                        <Package className="h-12 w-12 text-gray-600" />
                      </div>
                    </div>
                    <div className="md:w-3/4">
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
                        <div>
                          <h3 className="text-xl font-semibold capitalize">{pickup.donations?.food_type} Pickup</h3>
                          <p className="text-muted-foreground">
                            From: {pickup.donations?.profiles?.organization || pickup.donations?.profiles?.full_name}
                          </p>
                        </div>
                        <Badge className="w-fit bg-red-100 text-red-800 hover:bg-red-100">Cancelled</Badge>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="flex items-start gap-2">
                          <Calendar className="h-5 w-5 text-gray-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Scheduled Date</p>
                            <p className="text-gray-600">{new Date(pickup.scheduled_date).toLocaleDateString()}</p>
                          </div>
                        </div>

                        <div className="flex items-start gap-2">
                          <Package className="h-5 w-5 text-gray-500 mt-0.5" />
                          <div>
                            <p className="font-medium">Quantity</p>
                            <p className="text-gray-600">
                              {pickup.donations?.quantity} {pickup.donations?.unit}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
