"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import {
  Leaf,
  LayoutDashboard,
  Package,
  Calendar,
  Users,
  Settings,
  LogOut,
  Menu,
  X,
  Building2,
  Heart,
  History,
  MessageSquare,
  BarChart3,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface SidebarProps {
  role: "admin" | "donator" | "ngo"
}

export function DashboardSidebar({ role }: SidebarProps) {
  const pathname = usePathname()
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen)
  }

  const adminLinks = [
    { href: "/dashboard/admin", label: "Dashboard", icon: LayoutDashboard },
    { href: "/dashboard/admin/users", label: "Manage Users", icon: Users },
    { href: "/dashboard/admin/donations", label: "Donations", icon: Package },
    { href: "/dashboard/admin/reports", label: "Reports", icon: BarChart3 },
    { href: "/dashboard/admin/settings", label: "Settings", icon: Settings },
  ]

  const donatorLinks = [
    { href: "/dashboard/donator", label: "Dashboard", icon: LayoutDashboard },
    { href: "/dashboard/donator/donate", label: "Donate Food", icon: Heart },
    { href: "/dashboard/donator/history", label: "Donation History", icon: History },
    { href: "/dashboard/donator/schedule", label: "Schedule Pickup", icon: Calendar },
    { href: "/dashboard/donator/settings", label: "Settings", icon: Settings },
  ]

  const ngoLinks = [
    { href: "/dashboard/ngo", label: "Dashboard", icon: LayoutDashboard },
    { href: "/dashboard/ngo/available", label: "Available Donations", icon: Package },
    { href: "/dashboard/ngo/pickups", label: "Scheduled Pickups", icon: Calendar },
    { href: "/dashboard/ngo/history", label: "Collection History", icon: History },
    { href: "/dashboard/ngo/messages", label: "Messages", icon: MessageSquare },
    { href: "/dashboard/ngo/settings", label: "Settings", icon: Settings },
  ]

  const links = role === "admin" ? adminLinks : role === "donator" ? donatorLinks : ngoLinks
  const roleName = role === "admin" ? "Administrator" : role === "donator" ? "Food Donator" : "NGO Partner"
  const roleIcon = role === "admin" ? Users : role === "donator" ? Building2 : Heart

  return (
    <>
      {/* Mobile Menu Button */}
      <div className="lg:hidden fixed top-4 left-4 z-30">
        <Button variant="outline" size="icon" onClick={toggleMobileMenu} className="bg-white">
          {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      </div>

      {/* Sidebar for Desktop */}
      <div className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0">
        <div className="flex flex-col flex-grow bg-white border-r border-gray-200">
          <div className="flex items-center h-16 px-4 border-b">
            <Link href="/" className="flex items-center gap-2">
              <Leaf className="h-6 w-6 text-green-600" />
              <span className="text-xl font-bold">FoodShare</span>
            </Link>
          </div>
          <div className="flex-1 flex flex-col overflow-y-auto pt-5 pb-4">
            <div className="px-4 mb-6">
              <div className="bg-green-50 p-3 rounded-lg flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                  <roleIcon className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-900">{roleName}</p>
                  <p className="text-xs text-gray-500">ID: {role}-12345</p>
                </div>
              </div>
            </div>
            <nav className="flex-1 px-2 space-y-1">
              {links.map((link) => {
                const isActive = pathname === link.href
                const Icon = link.icon

                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    className={cn(
                      "group flex items-center px-2 py-2 text-sm font-medium rounded-md",
                      isActive ? "bg-green-100 text-green-700" : "text-gray-600 hover:bg-gray-50 hover:text-gray-900",
                    )}
                  >
                    <Icon
                      className={cn(
                        "mr-3 flex-shrink-0 h-5 w-5",
                        isActive ? "text-green-600" : "text-gray-400 group-hover:text-gray-500",
                      )}
                    />
                    {link.label}
                  </Link>
                )
              })}
            </nav>
          </div>
          <div className="p-4 border-t border-gray-200">
            <Button
              variant="outline"
              className="w-full justify-start text-gray-600 hover:text-gray-900 hover:bg-gray-50"
              asChild
            >
              <Link href="/login">
                <LogOut className="mr-3 h-5 w-5 text-gray-400" />
                Sign Out
              </Link>
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Sidebar */}
      {isMobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-20 flex">
          <div className="fixed inset-0 bg-gray-600 bg-opacity-75" onClick={toggleMobileMenu}></div>
          <div className="relative flex-1 flex flex-col max-w-xs w-full bg-white">
            <div className="flex items-center h-16 px-4 border-b">
              <Link href="/" className="flex items-center gap-2" onClick={toggleMobileMenu}>
                <Leaf className="h-6 w-6 text-green-600" />
                <span className="text-xl font-bold">FoodShare</span>
              </Link>
            </div>
            <div className="flex-1 flex flex-col overflow-y-auto pt-5 pb-4">
              <div className="px-4 mb-6">
                <div className="bg-green-50 p-3 rounded-lg flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                    <roleIcon className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">{roleName}</p>
                    <p className="text-xs text-gray-500">ID: {role}-12345</p>
                  </div>
                </div>
              </div>
              <nav className="flex-1 px-2 space-y-1">
                {links.map((link) => {
                  const isActive = pathname === link.href
                  const Icon = link.icon

                  return (
                    <Link
                      key={link.href}
                      href={link.href}
                      className={cn(
                        "group flex items-center px-2 py-2 text-sm font-medium rounded-md",
                        isActive ? "bg-green-100 text-green-700" : "text-gray-600 hover:bg-gray-50 hover:text-gray-900",
                      )}
                      onClick={toggleMobileMenu}
                    >
                      <Icon
                        className={cn(
                          "mr-3 flex-shrink-0 h-5 w-5",
                          isActive ? "text-green-600" : "text-gray-400 group-hover:text-gray-500",
                        )}
                      />
                      {link.label}
                    </Link>
                  )
                })}
              </nav>
            </div>
            <div className="p-4 border-t border-gray-200">
              <Button
                variant="outline"
                className="w-full justify-start text-gray-600 hover:text-gray-900 hover:bg-gray-50"
                asChild
              >
                <Link href="/login" onClick={toggleMobileMenu}>
                  <LogOut className="mr-3 h-5 w-5 text-gray-400" />
                  Sign Out
                </Link>
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
