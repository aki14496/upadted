import { createClient } from "@/lib/supabase/client"
import type { Database } from "@/lib/database.types"

type Pickup = Database["public"]["Tables"]["pickups"]["Row"]
type NewPickup = Database["public"]["Tables"]["pickups"]["Insert"]
type PickupUpdate = Database["public"]["Tables"]["pickups"]["Update"]

export const pickupService = {
  async createPickup(pickup: NewPickup) {
    const supabase = createClient()

    // Start a transaction
    // 1. Create the pickup
    const { data: pickupData, error: pickupError } = await supabase.from("pickups").insert(pickup).select().single()

    if (pickupError) throw pickupError

    // 2. Update the donation status to claimed
    const { error: donationError } = await supabase
      .from("donations")
      .update({ status: "claimed" })
      .eq("id", pickup.donation_id)

    if (donationError) throw donationError

    return pickupData
  },

  async getPickupsByNgo(ngoId: string) {
    const supabase = createClient()
    const { data, error } = await supabase
      .from("pickups")
      .select("*, donations(*), donations.profiles(full_name, organization)")
      .eq("ngo_id", ngoId)
      .order("scheduled_date", { ascending: true })

    if (error) throw error
    return data
  },

  async updatePickupStatus(id: string, status: "scheduled" | "completed" | "cancelled") {
    const supabase = createClient()

    const { data: pickup, error: pickupError } = await supabase
      .from("pickups")
      .select("donation_id")
      .eq("id", id)
      .single()

    if (pickupError) throw pickupError

    // Update pickup status
    const { data, error } = await supabase
      .from("pickups")
      .update({ status, updated_at: new Date().toISOString() })
      .eq("id", id)
      .select()
      .single()

    if (error) throw error

    // If pickup is completed, update donation status to collected
    if (status === "completed") {
      const { error: donationError } = await supabase
        .from("donations")
        .update({ status: "collected" })
        .eq("id", pickup.donation_id)

      if (donationError) throw donationError
    }

    // If pickup is cancelled, update donation status back to available
    if (status === "cancelled") {
      const { error: donationError } = await supabase
        .from("donations")
        .update({ status: "available" })
        .eq("id", pickup.donation_id)

      if (donationError) throw donationError
    }

    return data
  },

  async subscribeToPickups(ngoId: string, callback: (payload: any) => void) {
    const supabase = createClient()

    const subscription = supabase
      .channel(`pickups_${ngoId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "pickups",
          filter: `ngo_id=eq.${ngoId}`,
        },
        callback,
      )
      .subscribe()

    return subscription
  },
}
