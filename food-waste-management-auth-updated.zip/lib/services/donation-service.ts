import { createClient } from "@/lib/supabase/client"
import type { Database } from "@/lib/database.types"

type Donation = Database["public"]["Tables"]["donations"]["Row"]
type NewDonation = Database["public"]["Tables"]["donations"]["Insert"]
type DonationUpdate = Database["public"]["Tables"]["donations"]["Update"]

export const donationService = {
  async createDonation(donation: NewDonation) {
    const supabase = createClient()
    const { data, error } = await supabase.from("donations").insert(donation).select().single()

    if (error) throw error
    return data
  },

  async getDonationsByDonor(donorId: string) {
    const supabase = createClient()
    const { data, error } = await supabase
      .from("donations")
      .select("*, pickups(*)")
      .eq("donor_id", donorId)
      .order("created_at", { ascending: false })

    if (error) throw error
    return data
  },

  async getAvailableDonations() {
    const supabase = createClient()
    const { data, error } = await supabase
      .from("donations")
      .select("*, profiles(full_name, organization)")
      .eq("status", "available")
      .order("created_at", { ascending: false })

    if (error) throw error
    return data
  },

  async getDonationById(id: string) {
    const supabase = createClient()
    const { data, error } = await supabase
      .from("donations")
      .select("*, profiles(full_name, organization), images(*)")
      .eq("id", id)
      .single()

    if (error) throw error
    return data
  },

  async updateDonation(id: string, updates: DonationUpdate) {
    const supabase = createClient()
    const { data, error } = await supabase.from("donations").update(updates).eq("id", id).select().single()

    if (error) throw error
    return data
  },

  async deleteDonation(id: string) {
    const supabase = createClient()
    const { error } = await supabase.from("donations").delete().eq("id", id)

    if (error) throw error
    return true
  },

  async subscribeToAvailableDonations(callback: (payload: any) => void) {
    const supabase = createClient()

    const subscription = supabase
      .channel("available_donations")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "donations",
          filter: "status=eq.available",
        },
        callback,
      )
      .subscribe()

    return subscription
  },
}
