import { createClient } from "@/lib/supabase/client"

export const storageService = {
  async uploadDonationImage(donationId: string, file: File) {
    const supabase = createClient()

    // Generate a unique file name
    const fileExt = file.name.split(".").pop()
    const fileName = `${donationId}/${Date.now()}.${fileExt}`
    const filePath = `donations/${fileName}`

    // Upload the file to Supabase Storage
    const { data: uploadData, error: uploadError } = await supabase.storage.from("food-images").upload(filePath, file)

    if (uploadError) throw uploadError

    // Get the public URL
    const {
      data: { publicUrl },
    } = supabase.storage.from("food-images").getPublicUrl(filePath)

    // Save the image reference in the database
    const { data: imageData, error: imageError } = await supabase
      .from("images")
      .insert({
        donation_id: donationId,
        storage_path: filePath,
      })
      .select()
      .single()

    if (imageError) throw imageError

    return { ...imageData, publicUrl }
  },

  async getDonationImages(donationId: string) {
    const supabase = createClient()

    // Get image references from the database
    const { data: images, error } = await supabase.from("images").select("*").eq("donation_id", donationId)

    if (error) throw error

    // Get public URLs for each image
    const imagesWithUrls = images.map((image) => {
      const {
        data: { publicUrl },
      } = supabase.storage.from("food-images").getPublicUrl(image.storage_path)

      return { ...image, publicUrl }
    })

    return imagesWithUrls
  },

  async deleteImage(imagePath: string) {
    const supabase = createClient()

    // Delete from storage
    const { error: storageError } = await supabase.storage.from("food-images").remove([imagePath])

    if (storageError) throw storageError

    // Delete from database
    const { error: dbError } = await supabase.from("images").delete().eq("storage_path", imagePath)

    if (dbError) throw dbError

    return true
  },
}
