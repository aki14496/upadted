export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          email: string
          full_name: string | null
          role: "admin" | "donator" | "ngo"
          organization: string | null
          address: string | null
          phone: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email: string
          full_name?: string | null
          role: "admin" | "donator" | "ngo"
          organization?: string | null
          address?: string | null
          phone?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          full_name?: string | null
          role?: "admin" | "donator" | "ngo"
          organization?: string | null
          address?: string | null
          phone?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      donations: {
        Row: {
          id: string
          donor_id: string
          food_type: string
          quantity: number
          unit: string
          description: string | null
          expiry_date: string
          pickup_date: string | null
          pickup_time_slot: string | null
          address: string
          contact_name: string
          contact_phone: string
          status: "available" | "claimed" | "collected" | "expired"
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          donor_id: string
          food_type: string
          quantity: number
          unit: string
          description?: string | null
          expiry_date: string
          pickup_date?: string | null
          pickup_time_slot?: string | null
          address: string
          contact_name: string
          contact_phone: string
          status?: "available" | "claimed" | "collected" | "expired"
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          donor_id?: string
          food_type?: string
          quantity?: number
          unit?: string
          description?: string | null
          expiry_date?: string
          pickup_date?: string | null
          pickup_time_slot?: string | null
          address?: string
          contact_name?: string
          contact_phone?: string
          status?: "available" | "claimed" | "collected" | "expired"
          created_at?: string
          updated_at?: string
        }
      }
      pickups: {
        Row: {
          id: string
          donation_id: string
          ngo_id: string
          scheduled_date: string
          status: "scheduled" | "completed" | "cancelled"
          notes: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          donation_id: string
          ngo_id: string
          scheduled_date: string
          status?: "scheduled" | "completed" | "cancelled"
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          donation_id?: string
          ngo_id?: string
          scheduled_date?: string
          status?: "scheduled" | "completed" | "cancelled"
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      images: {
        Row: {
          id: string
          donation_id: string
          storage_path: string
          created_at: string
        }
        Insert: {
          id?: string
          donation_id: string
          storage_path: string
          created_at?: string
        }
        Update: {
          id?: string
          donation_id?: string
          storage_path?: string
          created_at?: string
        }
      }
    }
  }
}
